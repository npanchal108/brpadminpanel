export class Common {
   //RootUrl: string = 'http://localhost:38051';
   //RootUrl: string = 'https://portal.distone.com/adminportalapi';
   RootUrl:string='https://portal.distone.com/webapi';
   userurl: string = 'https://portal.distone.com/';
}

