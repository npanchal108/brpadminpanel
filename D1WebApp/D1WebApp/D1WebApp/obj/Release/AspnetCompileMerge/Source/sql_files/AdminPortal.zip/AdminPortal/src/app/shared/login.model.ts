export class Login {
    UserName: string;
    Password: string;
    IsRememberPassword: boolean;
    Param: '';
    LoginType: boolean
}
