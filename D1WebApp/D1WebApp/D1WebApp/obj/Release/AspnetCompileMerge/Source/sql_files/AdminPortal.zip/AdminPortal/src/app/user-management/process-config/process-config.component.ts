import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { MailConfig } from '../../model/mail-config.model';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ProcessTime } from '../../shared/processtime.model';
import { UserProcessTimes } from '../../shared/userprocesstime.model';
import { Common } from '../../services/common.model';
import { UserprocesstimeService } from '../../shared/userprocesstime.service';
import { NgForm } from '@angular/forms';
import { LoadingService } from '../../services/loading.service';


@Component({
  selector: 'app-process-config',
  templateUrl: './process-config.component.html',
  styleUrls: ['./process-config.component.css']
})
export class ProcessConfigComponent implements OnInit {
  memRefNo: string;
  userProcessTimes: UserProcessTimes;
  schedulerData: any = [];
  userType: string;
  processtimes: any;
  foods: string[] = ['Daily', 'Weekly', 'Monthly'];
  foods1: string[] = ['Hourly', 'Daily'];
  foods2: string[] = ['5 Mins', '15 Mins', '30 Mins'];
  toppingList: string[] = ['cu_shipto', 'it_majcls', 'sy_company', 'sy_country', 'sy_paycodes', 'sy_prof_label', 'sy_shipvia', 'warehouse', 'wa_item', 'vendor', 'sy_terms', 'sy_postal_code', 'sy_param', 'sy_contact', 'states', 'sy_codes', 'salesman', 'oe_totcodes', 'item', 'it_tree_node', 'it_tree_link', 'it_prodline', 'customer'];

  date: Date = new Date();
  settings = {
    bigBanner: true,
    timePicker: true,
    format: 'MM/dd/yyyy hh:mm a',
    defaultOpen: false
  }
  userroles:string;
  isdesable=false;
  constructor(private route: ActivatedRoute, private userprocesstimeService: UserprocesstimeService, private toastr: ToastrService, private router: Router, private loadingService: LoadingService, private changeDetectorRef: ChangeDetectorRef) {
    console.log(location.origin);
  }

  ngOnInit() {
    this.sendMessage('start');
    this.getProcessTimeList();
    this.memRefNo = this.route.snapshot.paramMap.get('memRefNo');
    this.userType = this.route.snapshot.paramMap.get('userType');
    this.userroles = localStorage.getItem('Role');
    if(this.userroles=='Admin'){
      this.isdesable=false;
    }
    else{
      this.isdesable=true;
    }
    this.userprocesstimeService.getUserProcessTime(this.memRefNo).subscribe((data: any) => {
      this.userProcessTimes = data;
      this.userProcessTimes.MemRefNo = this.memRefNo;
    });

    this.sendMessage('stop');
  }
  sendMessage(message): void {
    this.loadingService.LoadingMessage(message);
  }
  getProcessTimeList() {
    this.userprocesstimeService.getProcessTimeList().subscribe((data: any) => {
      this.processtimes = data;
    });
  }

  SyncNow() {
    this.sendMessage('start');
    var geturl = location.origin + '/' + this.memRefNo + 'Api/DistOneApi/DataMigration';
    console.log(geturl);
    this.userprocesstimeService.SyncNow(geturl).subscribe((data: any) => {
      this.sendMessage('stop');
      this.toastr.success(data);
    });
    this.sendMessage('stop');
  }

  AllProductImages(){
    this.sendMessage('start');
    var geturl = location.origin + '/' + this.memRefNo + 'Api/DistOneApi/SetAllProductImages';
    this.userprocesstimeService.setallimages(geturl).subscribe((data: any) => {
      this.sendMessage('stop');
      this.toastr.success(data);
    });
    this.sendMessage('stop');
  }

  ProductImages(){
    this.sendMessage('start');
    var geturl = location.origin + '/' + this.memRefNo + 'Api/DistOneApi/SetProductImages';
    this.userprocesstimeService.setallimages(geturl).subscribe((data: any) => {
      this.sendMessage('stop');
      this.toastr.success(data);
    });
    this.sendMessage('stop');
  }

  AllTreeImages(){
    this.sendMessage('start');
    var geturl = location.origin + '/' + this.memRefNo + 'Api/DistOneApi/SetAllTreeImages';
    this.userprocesstimeService.setallimages(geturl).subscribe((data: any) => {
      this.sendMessage('stop');
      this.toastr.success(data);
    }); 
    this.sendMessage('stop');
  }
  TreeImages(){
    this.sendMessage('start');
    var geturl = location.origin + '/' + this.memRefNo + 'Api/DistOneApi/SetTreeImages';
    this.userprocesstimeService.setallimages(geturl).subscribe((data: any) => {
      this.sendMessage('stop');
      this.toastr.success(data);
    });
    this.sendMessage('stop');
  }

  ImageNow() {
    this.sendMessage('start');
    var geturl = location.origin + '/' + this.memRefNo + 'Api/DistOneApi/Setallimages';

    this.userprocesstimeService.setallimages(geturl).subscribe((data: any) => {
      this.sendMessage('stop');
      this.toastr.success(data);
    });
    this.sendMessage('stop');
  }
  AllImageNow() {
    this.sendMessage('start');
    var geturl = location.origin + '/' + this.memRefNo + 'Api/DistOneApi/SetallNewimages';
    this.userprocesstimeService.setallNewimages(geturl).subscribe((data: any) => {
      this.sendMessage('stop');
      this.toastr.success(data);
    });
    this.sendMessage('stop');
  }

  OnSubmit(form: NgForm) {
    // this.sendMessage('start');
    // this.userprocesstimeService.insertUser(form.value).subscribe((data: any) => {
    //   if (data.Status == "Success") {
    //     form.resetForm();
    //     this.toastr.success(data.Message);
    //     this.router.navigate(['/userlist', this.userType]);
    //   }
    //   else {
    //     this.toastr.error(data.Message);
    //   }
    //   this.sendMessage('stop');
    // });

    console.log()
  }

  addScheduler1Config(form: NgForm) {
    var data = form.value;
    var model = {
      "MemRefNo": this.memRefNo,
      "SchedulerName": "Scheduler1",
      "SchedulerTime": data.SchedulerTime1,
      "SchedulerTables": JSON.stringify(data.Table1)
    };
    this.userprocesstimeService.insertScheduler1(model).subscribe((data: any) => {
      if (data.Status == "Success") {
        this.toastr.success("Scheduler inserted successfully.");
      }
      else {
        this.toastr.success("Something went wrong. Please try again later.");
      }
    });
  }

  addScheduler2Config(form: NgForm) {
    var data = form.value;
    var model = {
      "MemRefNo": this.memRefNo,
      "SchedulerName": "Scheduler2",
      "SchedulerTime": data.SchedulerTime2,
      "SchedulerTables": JSON.stringify(data.Table2)
    };
    this.userprocesstimeService.insertScheduler1(model).subscribe((data: any) => {
      if (data.Status == "Success") {
        this.toastr.success("Scheduler inserted successfully.");
      }
      else {
        this.toastr.success("Something went wrong. Please try again later.");
      }
    });
  }

  addScheduler3Config(form: NgForm) {
    var data = form.value;
    var model = {
      "MemRefNo": this.memRefNo,
      "SchedulerName": "Scheduler3",
      "SchedulerTime": data.SchedulerTime3,
      "SchedulerTables": JSON.stringify(data.Table3)
    };
    this.userprocesstimeService.insertScheduler1(model).subscribe((data: any) => {
      if (data.Status == "Success") {
        this.toastr.success("Scheduler inserted successfully.");
      }
      else {
        this.toastr.success("Something went wrong. Please try again later.");
      }
    });
  }

  back() {
    this.router.navigate(['/userlist', this.userType]);
  }

  syncTblNow() {
    this.sendMessage('start');
    var geturl = location.origin + '/' + this.memRefNo + 'Api/DistOneApi/syncasperconfig';
    //var geturl = 'http://localhost:50144/DistOneApi/syncasperconfig'
    console.log(geturl);

    var model = {
      "LastSync": this.getdatetime(new Date(this.date)),
      "TableNames": JSON.stringify(this.schedulerData.Table4)
    }

    this.userprocesstimeService.syncTblNow(model, geturl).subscribe((data: any) => {
      this.sendMessage('stop');
      this.toastr.success(data);
    });
    this.sendMessage('stop');
  }

  getdatetime(dt) {
    var res = "";
    res += this.formatdigits(dt.getMonth() + 1);
    res += "/";
    res += this.formatdigits(dt.getDate());
    res += "/";
    res += this.formatdigits(dt.getFullYear());
    res += " ";
    res += this.formatdigits(dt.getHours() > 12 ? dt.getHours() - 12 : dt.getHours());
    res += ":";
    res += this.formatdigits(dt.getMinutes());
    res += ":";
    res += this.formatdigits(dt.getSeconds());

    var ampm;
    if (dt.getHours() > 11) {
      ampm = " PM";
    }
    else {
      ampm = " AM";
    }

    //res += " " + dt.getHours() > 11 ? " PM" : " AM";
    res += " " + ampm;

    return res;
  }

  formatdigits(val) {
    val = val.toString();
    return val.length == 1 ? "0" + val : val;
  }
}
