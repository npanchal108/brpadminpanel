export class CompanyProfile {
    UserMemRefNo: string;
    CompanyID: number;
    CompanyName: string;
    CompanyAddress: string;
    CompanyInfo: string;
    CompanyVision: string;
    CompanyMission: string;
    CompanyEmail: string;
    CompanyContact1: string;
    CompanyContact2: string;
    CompanyMobile1: string;
    CompanyMobile2: string;
    ButtenText: string = "Submit";
}
