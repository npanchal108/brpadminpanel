export class Common {
   //RootUrl: string = 'http://localhost:38051';
   RootUrl: string = 'https://portal.distone.com/Webapi';
   userurl: string = 'https://portal.distone.com/';
}
   