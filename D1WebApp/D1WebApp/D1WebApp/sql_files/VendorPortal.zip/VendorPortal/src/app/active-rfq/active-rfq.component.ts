import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { QuoteService } from '../services/quote.service';
import { NgForm } from '@angular/forms';
import { LoadingService } from '../services/loading.service';
declare var $: any;

@Component({
  selector: 'app-active-rfq',
  templateUrl: './active-rfq.component.html',
  styleUrls: ['./active-rfq.component.css']
})
export class ActiveRfqComponent implements OnInit {

  quoteList: any;
  btnText: string;
  isProductLine: boolean = false;
  rfqTitle: string;
  isShow: boolean = true;

  productLine: any;
  page: number = 1;
  LNPage: number = 1;
  totalPage: number;
  totalLinePage: number;
  searchModel: any = [];

  constructor(private router: Router, private quoteServie: QuoteService, private route: ActivatedRoute, private loadingService: LoadingService) {

  }

  ngOnInit() {
    $('.nav li').removeClass('active');
    $('#liRFQ').addClass('active');
    this.rfqTitle = "Active RFQ";
    this.btnText = "Show Product Line Quote";
    this.getQuoteList(this.page);
    this.getQuoteListCount();
    this.getProductLineCount();
  }

  getQuoteList(pageNo) {
    var PO = this.searchModel.PO == undefined?"":this.searchModel.PO;
    var PartNo = this.searchModel.PartNo == undefined?"":this.searchModel.PartNo;
    var VendorPart = this.searchModel.VendorPart == undefined?"":this.searchModel.VendorPart;
    var UPC = this.searchModel.UPC == undefined ?"":this.searchModel.UPC;
    var OrdDate = this.searchModel.Date == undefined?"":this.searchModel.Date;

    this.quoteServie.getQuoteList(pageNo, PO, PartNo, VendorPart, UPC, OrdDate).subscribe((res: any) => {
      this.quoteList = res;
    });
    return pageNo;
  }

  getQuoteListCount() {
    this.quoteServie.getQuoteListCount().subscribe((res: any) => {
      this.totalPage = (res == null ? 0 : res.count);
    });
  }

  getProductLine(pageNo) {
    this.quoteServie.getProductLine(pageNo).subscribe((res: any) => {
      for (var i = 0; i < res.length; i++) {
        var des = res[i].po_line_descr[0] + "\n" + res[i].po_line_descr[1];
        res[i].po_line_descr = des;
      }

      this.productLine = res;
    });
    return pageNo;
  }

  getProductLineCount() {
    this.quoteServie.getProductLineCount().subscribe((res: any) => {
      this.totalLinePage = (res == null ? 0 : res.count);
    });
  }
  OnClear(form: NgForm) {
    form.reset();
    this.isShow = true;
    if (this.btnText == "Show Product Line Quote") {
      this.btnText = "Show Product Line Quote";
      this.rfqTitle = "Active RFQ";
      this.isProductLine = false;
      this.getQuoteList(this.page);
    }
    else {
      this.isProductLine = true;
      this.btnText = "Show Quote";
      this.rfqTitle = "Active Product Line RFQ";
      this.getProductLine(this.LNPage);
    }

  }
  showProductLineQuote() {
    if (this.btnText == "Show Product Line Quote") {
      this.isProductLine = true;
      this.btnText = "Show Quote";
      this.rfqTitle = "Active Product Line RFQ";
      this.getProductLine(this.LNPage);
    }
    else {
      this.btnText = "Show Product Line Quote";
      this.rfqTitle = "Active RFQ";
      this.isProductLine = false;
      this.getQuoteList(this.page);
    }
  }

  onView(quoteNo) {
    this.router.navigate(['/view-rfq', quoteNo]);
  }

  onLineView(quoteNo, partNo) {
    this.router.navigate(['/view-rfq', quoteNo, partNo]);
  }

  OnSubmit(form: NgForm) {
    this.quoteServie.GetSearchBYPart(form.value.PartNo).subscribe((res: any) => {
      this.quoteList = res;
      this.productLine = res;
      this.isShow = false;
    });
  }

  sendMessage(message): void {
    this.loadingService.LoadingMessage(message);
  }

  search() {
    console.log("search model : ", this.searchModel);
    this.getQuoteList(this.page);    
  }
}
