import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PoService } from '../services/po.service';
import { QuoteList } from '../mock-data/quote-list';
import { NgForm } from '@angular/forms';
import { LoadingService } from '../services/loading.service';
declare var $: any;

@Component({
  selector: 'app-active-po',
  templateUrl: './active-po.component.html',
  styleUrls: ['./active-po.component.css']
})
export class ActivePoComponent implements OnInit {

  poList: any;
  productLinePO: any;
  btnText: string;
  isProductLine: boolean = false;
  isShow: boolean = true;
  poTitle: string;

  page: number = 1;
  LNpage: number = 1;

  totalPage: number;
  totalLinePage: number;
  searchModel: any = [];

  constructor(private router: Router, private poService: PoService, private loadingService: LoadingService) { }

  ngOnInit() {
    $('.nav li').removeClass('active');
    $('#liPO').addClass('active');
    this.btnText = "Show Product Line PO";
    this.getOrderList(this.page);
    this.poTitle = "Active PO";
    this.getOrderListCount();
    this.getProductLinePOCount();
  }

  getOrderList(pageNo) {
    var PO = this.searchModel.PO == undefined?"":this.searchModel.PO;
    var PartNo = this.searchModel.PartNo == undefined?"":this.searchModel.PartNo;
    var VendorPart = this.searchModel.VendorPart == undefined?"":this.searchModel.VendorPart;
    var UPC = this.searchModel.UPC == undefined ?"":this.searchModel.UPC;
    var OrdDate = this.searchModel.Date == undefined?"":this.searchModel.Date;

    this.poService.getPOList(pageNo, PO, PartNo, VendorPart, UPC, OrdDate).subscribe((res: any) => {
      this.poList = res;
    });
    return pageNo;
  }

  getOrderListCount() {
    this.poService.getPOListCount().subscribe((res: any) => {
      this.totalPage = (res == null ? 0 : res.count);
    });
  }

  getProductLinePO(pageNo) {
    this.poService.getProductLinePO(pageNo).subscribe((res: any) => {
      for (var i = 0; i < res.length; i++) {
        var des = res[i].po_line_descr[0] + "\n" + res[i].po_line_descr[1];
        res[i].po_line_descr = des;
      }

      this.productLinePO = res;
    });
    return pageNo;
  }

  getProductLinePOCount() {
    this.poService.getProductLinePOCount().subscribe((res: any) => {
      this.totalLinePage = (res == null ? 0 : res.count);
    });
  }

  showProductLinePO() {
    if (this.btnText == "Show Product Line PO") {
      this.isProductLine = true;
      this.btnText = "Show PO";
      this.poTitle = "Active Product Line PO";
      this.getProductLinePO(this.LNpage);
    }
    else {
      this.btnText = "Show Product Line PO";
      this.poTitle = "Active PO";
      this.isProductLine = false;
      this.getOrderList(this.page);
    }
  }

  onView(poNo) {
    this.router.navigate(['/view-po', poNo]);
  }

  onLineView(quoteNo, partNo) {
    this.router.navigate(['/view-po', quoteNo, partNo]);
  }

  OnSubmit(form: NgForm) {
    this.poService.GetSearchBYPart(form.value.PartNo).subscribe((res: any) => {
      this.productLinePO = res;
      this.poList = res;
      this.isShow = false;
    });
  }

  OnClear(form: NgForm) {
    form.reset();
    this.isShow = true;
    if (this.btnText == "Show Product Line PO") {
      this.btnText = "Show Product Line PO";
      this.poTitle = "Active PO";
      this.isProductLine = false;
      this.getOrderList(this.page);
    }
    else {
      this.isProductLine = true;
      this.btnText = "Show PO";
      this.poTitle = "Active Product Line PO";
      this.getProductLinePO(this.LNpage);
    }

  }

  sendMessage(message): void {
    this.loadingService.LoadingMessage(message);
  }

  search() {
    console.log("search model : ", this.searchModel);
    this.getOrderList(this.page);    
  }
}
