import { Component, OnInit } from '@angular/core';
import { QuoteService } from '../services/quote.service';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { LoadingService } from '../services/loading.service';
import { Toast, ToastrService } from 'ngx-toastr';
import { PoService } from '../services/po.service';
declare const $: any;

@Component({
  selector: 'app-view-rfq',
  templateUrl: './view-rfq.component.html',
  styleUrls: ['./view-rfq.component.css']
})
export class ViewRfqComponent implements OnInit {

  quoteDtl: any;
  quoteNo: string;
  partNo: string;
  viewRfqTitle: string;
  success: boolean = false;
  error: boolean = false;

  constructor(private quoteServie: QuoteService, private toastr: ToastrService, private route: ActivatedRoute, private router: Router, private loadingService: LoadingService, private poServie: PoService) {

  }
  sendMessage(message): void {
    this.loadingService.LoadingMessage(message);
  }
  ngOnInit() {
    this.quoteNo = this.route.snapshot.paramMap.get('quoteNo');
    this.partNo = this.route.snapshot.paramMap.get('partNo');
    if (this.partNo != null) {
      this.viewRfqTitle = "View Product Line RFQ";
    }
    else {
      this.viewRfqTitle = "View RFQ";
    }
    this.getQuoteDtl();
  }

  getQuoteDtl() {
    this.quoteServie.getQuoteDtl(this.quoteNo).subscribe(res => {
      this.quoteDtl = res;

      if (this.partNo != null) {
        var i = 0;
        setTimeout(() => {
          for (let prodline of this.quoteDtl) {
            if (prodline.po_line_item != this.partNo) {
              $("#panel" + i).hide();
            }
            i++;
          }
        }, 1000);
      }
    });
  }

  OnSubmit(form: NgForm) {
    var model = [
      {
        "vendor": this.quoteDtl[0].vendor,
        "ship_ID": this.quoteDtl[0].ship_ID,
        "ship_via_code": this.quoteDtl[0].ship_via_code,
        "name": this.quoteDtl[0].name,
        "ship_atn": this.quoteDtl[0].ship_atn,
        "adr": this.quoteDtl[0].adr,
        "state": this.quoteDtl[0].state,
        "postal_code": this.quoteDtl[0].postal_code,
        "country_code": this.quoteDtl[0].country_code,
        "phone": this.quoteDtl[0].phone,
        "phone_ext": this.quoteDtl[0].phone_ext,
        "fax": this.quoteDtl[0].fax,
        "email": this.quoteDtl[0].email,
        "PO": this.quoteDtl[0].PO,
        "ord_date": this.quoteDtl[0].ord_date,
        "wanted_date": this.quoteDtl[0].wanted_date,
        "follow_up_date": this.quoteDtl[0].follow_up_date,
        "follow_up_code": this.quoteDtl[0].follow_up_code,
        "currency_code": this.quoteDtl[0].currency_code,
        "exchange_rate": this.quoteDtl[0].exchange_rate,
        "Delivey_terms": this.quoteDtl[0].Delivey_terms,
        "enter_by": this.quoteDtl[0].enter_by,
        "product_line": []
      }
    ];
    var prodModel = [];
    for (let qq of this.quoteDtl) {
      prodModel.push({
        "line": qq.po_line_line,
        "line_add": qq.po_line_line_add,
        "item": qq.po_line_item,
        "upc1": qq.upc1,
        "descr1": qq.po_line_descr[0],
        "descr2": qq.po_line_descr[1],
        "q_ord_d": qq.po_line_q_ord_d,
        "um_o": qq.po_line_um_o,
        "req_date": qq.po_line_req_date,
        "unitcost": qq.unitcost,
        "orderedext": qq.orderedext,
        "rohs": qq.rohs,
        "condition": qq.condition,
        "packaging": qq.packaging,
        "delivery": qq.delivery,
        "packqty": qq.packqty,
        "minqty": qq.minqty,
        "instock": qq.instock,
        "expdate": qq.expdate,
        "Note": qq.Note

      });
    }
    model[0].product_line = prodModel;
    this.quoteServie.sendEmail(model[0]).subscribe((res: any) => {
      console.log(res);
      if (res == true) {
        this.toastr.success("Mail Sent Successfully");
      }
      else {
        this.toastr.success("Please try again");
      }
    });

    console.log("final model : ", model[0]);

    var poModel = [];

    for (let po of this.quoteDtl) {
      poModel.push({ "RecType": "Q", "PO": po.PO, "line_add": po.po_line_line_add, "wanted_date": po.po_line_wanted_date, "price": po.unitcost });
    }

    this.poServie.submitPO(poModel).subscribe((res: any) => {
      if (res) {
        this.success = true;
        this.error = false;
      }
      else {
        this.success = false;
        this.error = true;
      }
    });

    console.log("final model : ", poModel);

  }

  Sliding(i) {
    $("#panel" + i).slideToggle("slow");
  }

  clear(form: NgForm) {
    form.reset();
  }

  noBid() {
    this.router.navigate(['/active-rfq'])
  }

}


