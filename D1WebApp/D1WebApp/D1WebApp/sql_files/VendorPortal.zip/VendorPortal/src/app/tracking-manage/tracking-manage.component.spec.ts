import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TrackingManageComponent } from './tracking-manage.component';

describe('TrackingManageComponent', () => {
  let component: TrackingManageComponent;
  let fixture: ComponentFixture<TrackingManageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TrackingManageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TrackingManageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
