import { Component, OnInit } from '@angular/core';
import { PoService } from '../services/po.service';
import { QuoteView } from '../mock-data/quote-view';
import { ActivatedRoute, Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { LoadingService } from '../services/loading.service';
import { Toast, ToastrService } from 'ngx-toastr';
import { QuoteService } from '../services/quote.service';
declare const $: any;

@Component({
  selector: 'app-view-po',
  templateUrl: './view-po.component.html',
  styleUrls: ['./view-po.component.css']
})
export class ViewPoComponent implements OnInit {

  poDtl: any;
  poNo: string;
  partNo: string;
  viewPoTitle: string;
  trackingList: any;
  success: boolean = false;
  error: boolean = false;
  message: string;

  constructor(private poServie: PoService, private toastr: ToastrService, private route: ActivatedRoute, private router: Router, private loadingService: LoadingService,
    private quoteService: QuoteService) { }
  sendMessage(message): void {
    this.loadingService.LoadingMessage(message);
  }
  ngOnInit() {
    this.poNo = this.route.snapshot.paramMap.get('poNo');
    this.partNo = this.route.snapshot.paramMap.get('partNo');
    if (this.partNo != null) {
      this.viewPoTitle = "View Product Line PO";
    }
    else {
      this.viewPoTitle = "View PO";
    }
    this.getPODtl();

  }

  getTrackingNo(orderId) {

    var manifestId = "PO-" + orderId;
    this.quoteService.getTracking(manifestId).subscribe((res: any) => {
      console.log("data : ", res);
      this.trackingList = res;
    });
  }

  OnSubmit(form: NgForm) {
    var model = [
      {
        "vendor": this.poDtl[0].vendor,
        "ship_ID": this.poDtl[0].ship_ID,
        "ship_via_code": this.poDtl[0].ship_via_code,
        "name": this.poDtl[0].name,
        "ship_atn": this.poDtl[0].ship_atn,
        "adr": this.poDtl[0].adr,
        "state": this.poDtl[0].state,
        "postal_code": this.poDtl[0].postal_code,
        "country_code": this.poDtl[0].country_code,
        "phone": this.poDtl[0].phone,
        "phone_ext": this.poDtl[0].phone_ext,
        "fax": this.poDtl[0].fax,
        "email": this.poDtl[0].email,
        "PO": this.poDtl[0].PO,
        "ord_date": this.poDtl[0].ord_date,
        "wanted_date": this.poDtl[0].wanted_date,
        "follow_up_date": this.poDtl[0].follow_up_date,
        "follow_up_code": this.poDtl[0].follow_up_code,
        "currency_code": this.poDtl[0].currency_code,
        "exchange_rate": this.poDtl[0].exchange_rate,
        "Delivey_terms": this.poDtl[0].Delivey_terms,
        "enter_by": this.poDtl[0].enter_by,
        "product_line": []
      }
    ];


    var prodModel = [];
    for (let qq of this.poDtl) {
      prodModel.push({
        "line": qq.po_line_line,
        "line_add": qq.po_line_line_add,
        "item": qq.po_line_item,
        "upc1": qq.upc1,
        "descr1": qq.po_line_descr[0],
        "descr2": qq.po_line_descr[1],
        "q_ord_d": qq.po_line_q_ord_d,
        "um_o": qq.po_line_um_o,
        "req_date": qq.po_line_req_date,
        "unitcost": qq.unitcost,
        "orderedext": qq.orderedext,
        "rohs": qq.rohs,
        "condition": qq.condition,
        "packaging": qq.packaging,
        "delivery": qq.delivery,
        "packqty": qq.packqty,
        "minqty": qq.minqty,
        "instock": qq.instock,
        "expdate": qq.expdate,
        "Note": qq.Note

      });
    }
    model[0].product_line = prodModel;
    this.poServie.sendEmail(model[0]).subscribe((res: any) => {
      console.log(res);
      if (res == true) {
        this.toastr.success("Mail Sent Successfully");
      }
      else {
        this.toastr.error("Please try again");
      }
    });

    var poModel = [];

    for (let po of this.poDtl) {
      poModel.push({ "RecType": "O", "PO": po.PO, "line_add": po.po_line_line_add, "wanted_date": po.po_line_wanted_date, "price": "" });
    }

    this.poServie.submitPO(poModel).subscribe((res: any) => {
      if (res) {
        this.success = true;
        this.error = false;
      }
      else {
        this.success = false;
        this.error = true;
      }
    });

    console.log("final model : ", poModel);
  }
  getPODtl() {
    this.poServie.getPODtl(this.poNo).subscribe(res => {
      this.poDtl = res;
      console.log()
      this.getTrackingNo(this.poDtl[0].PO);
      if (this.partNo != null) {
        var i = 0;
        setTimeout(() => {
          for (let prodline of this.poDtl) {
            if (prodline.po_line_item != this.partNo) {
              $("#panel" + i).hide();
            }
            i++;
          }
        }, 1000);
      }
    });
  }

  clear(form: NgForm) {
    form.reset();
  }

  noBid() {
    this.router.navigate(['/active-po'])
  }
  Sliding(i) {
    $("#panel" + i).slideToggle("slow");
  }

  InsertNo() {
    console.log("part no : ", this.partNo);
    if (this.partNo == null)
      this.router.navigate(['/tracking', this.poNo]);
    else
      this.router.navigate(['/tracking', this.poNo, this.partNo]);
  }

}
