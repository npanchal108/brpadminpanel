import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Common } from './common.model';

@Injectable()
export class PoService {

  common: Common;
  Paging = 1;

  constructor(private http: HttpClient) {
    this.common = new Common();
  }

  getPOList(pageNo, PO, PartNo, VendorPart, UPC, OrdDate) {
    var reqHeader = new HttpHeaders({ 'Content-Type': 'application/json', 'No-Auth': 'True' });
    return this.http.get(this.common.AdminURL + '/DistOneAPi/getPOList?UserID=' + this.common.UserID + "&RecType=O&vendor=" + localStorage.getItem('vendor') + "&pageno=" + pageNo + "&PO=" + PO + "&PartNo=" + PartNo + "&VendorPart=" + VendorPart + "&UPC=" + UPC + "&Date=" + OrdDate, { headers: reqHeader });
  }

  getPOListCount() {
    var reqHeader = new HttpHeaders({ 'Content-Type': 'application/json', 'No-Auth': 'True' });
    return this.http.get(this.common.AdminURL + '/DistOneAPi/getPOListCount?UserID=' + this.common.UserID + "&RecType=O&vendor=" + localStorage.getItem('vendor'), { headers: reqHeader });
  }

  sendEmail(obj) {
    obj.UserID = this.common.UserID;
    return this.http.post(this.common.AdminURL + '/DistOneAPi/SendOfferDetailsMail', obj);
  }
  getProductLinePO(pageNo) {
    // var reqHeader = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded', 'Authorization': this.common.AuthenticationToken });
    // var query = "FOR EACH po_head NO-LOCK WHERE  po_head.company_it = '" + this.common.CompanyID + "' and po_head.rec_type = 'O' and po_head.vendor = '"+localStorage.getItem('vendor')+"' and opn ='yes', EACH po_line NO-LOCK WHERE po_line.po = po_head.po AND po_line.rec_seq = po_head.rec_seq AND po_line.rec_type = po_head.rec_type AND po_line.company_it = po_head.company_it";
    // var coloumn = "po,po_line.line,po_line.line_add,po_line.item,po_line.descr,po_line.q_ord_d,po_line.um_o,po_line.price,po_line.o_ext,po_line.req_date,po_line.wanted_date";
    // return this.http.post(this.common.RootUrl + "/distone/rest/service/data/read", "query=" + query + "&columns=" + coloumn + "&take=" + this.Paging, { headers: reqHeader });
    var reqHeader = new HttpHeaders({ 'Content-Type': 'application/json', 'No-Auth': 'True' });
    return this.http.get(this.common.AdminURL + '/DistOneAPi/getProductLinePO?UserID=' + this.common.UserID + "&RecType=O&vendor=" + localStorage.getItem('vendor') + "&PageNo=" + pageNo, { headers: reqHeader });
  }

  getProductLinePOCount() {
    // var reqHeader = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded', 'Authorization': this.common.AuthenticationToken });
    // var query = "FOR EACH po_head NO-LOCK WHERE  po_head.company_it = '" + this.common.CompanyID + "' and po_head.rec_type = 'O' and po_head.vendor = '"+localStorage.getItem('vendor')+"' and opn ='yes', EACH po_line NO-LOCK WHERE po_line.po = po_head.po AND po_line.rec_seq = po_head.rec_seq AND po_line.rec_type = po_head.rec_type AND po_line.company_it = po_head.company_it";
    // var coloumn = "po,po_line.line,po_line.line_add,po_line.item,po_line.descr,po_line.q_ord_d,po_line.um_o,po_line.price,po_line.o_ext,po_line.req_date,po_line.wanted_date";
    // return this.http.post(this.common.RootUrl + "/distone/rest/service/data/read", "query=" + query + "&columns=" + coloumn + "&take=" + this.Paging, { headers: reqHeader });
    var reqHeader = new HttpHeaders({ 'Content-Type': 'application/json', 'No-Auth': 'True' });
    return this.http.get(this.common.AdminURL + '/DistOneAPi/getProductLinePOCount?UserID=' + this.common.UserID + "&RecType=O&vendor=" + localStorage.getItem('vendor'), { headers: reqHeader });
  }

  getPODtl(poNo) {
    // var reqHeader = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded', 'Authorization': this.common.AuthenticationToken });
    // var query = "FOR EACH po_head NO-LOCK WHERE  po_head.company_it = '" + this.common.CompanyID + "' and po_head.vendor = '"+localStorage.getItem('vendor')+"' and po_head.po = '" + poNo + "' and opn ='yes', EACH po_line NO-LOCK WHERE po_line.po = po_head.po AND po_line.rec_seq = po_head.rec_seq AND po_line.rec_type = po_head.rec_type AND po_line.company_it = po_head.company_it";
    // var coloumn = "vendor,PO,rec_type,ord_date,wanted_date,follow_up_date,follow_up_code,currency_code,exchange_rate,delivery_terms,enter_by,fax,ship_ID,ship_via_code,name,ship_atn,adr,state,postal_code,phone,phone_ext,email,country_code,po_line.line,po_line.line_add,po_line.item,po_line.descr,po_line.q_ord_d,po_line.um_o,po_line.price,po_line.o_ext,po_line.req_date,po_line.wanted_date";
    // return this.http.post(this.common.RootUrl + "/distone/rest/service/data/read", "query=" + query + "&columns=" + coloumn + "&take=" + this.Paging, { headers: reqHeader });
    var reqHeader = new HttpHeaders({ 'Content-Type': 'application/json', 'No-Auth': 'True' });
    return this.http.get(this.common.AdminURL + '/DistOneAPi/getPoDtl?UserID=' + this.common.UserID + "&vendor=" + localStorage.getItem('vendor') + "&PONO=" + poNo, { headers: reqHeader });
  }

  GetSearchBYPart(sword) {
    var reqHeader = new HttpHeaders({ 'Content-Type': 'application/json', 'No-Auth': 'True' });
    return this.http.get(this.common.AdminURL + '/DistOneAPi/SearchByPart?UserID=' + this.common.UserID + "&RecType=O&vendor=" + localStorage.getItem('vendor') + "&sword=" + sword, { headers: reqHeader });
  }

  getItemListCount(item, vendorItem, warehouse) {
    var reqHeader = new HttpHeaders({ 'Content-Type': 'application/json', 'No-Auth': 'True' });
    return this.http.get(this.common.AdminURL + '/DistOneAPi/getItemListCount?UserID=' + this.common.UserID + "&vendor=" + localStorage.getItem('vendor') + "&Item=" + item + "&VendorItem=" + vendorItem + "&Warehouse=" + warehouse, { headers: reqHeader });
  }

  getItemList(item, vendorItem, warehouse, pageNo) {
    var reqHeader = new HttpHeaders({ 'Content-Type': 'application/json', 'No-Auth': 'True' });
    return this.http.get(this.common.AdminURL + '/DistOneAPi/getItemList?UserID=' + this.common.UserID + "&vendor=" + localStorage.getItem('vendor') + "&Item=" + item + "&VendorItem=" + vendorItem + "&Warehouse=" + warehouse + "&PageNo=" + pageNo, { headers: reqHeader });
  }

  getItemAvailibilty(model) {
    model.UserID = this.common.UserID;
    var reqHeader = new HttpHeaders({ 'Content-Type': 'application/json', 'No-Auth': 'True' });
    return this.http.post(this.common.AdminURL + '/DistOneAPi/Itemavailability', model, { headers: reqHeader });
  }

  submitPO(model) {
    model[0].UserID = this.common.UserID;
    var reqHeader = new HttpHeaders({ 'Content-Type': 'application/json', 'No-Auth': 'True' });
    return this.http.post(this.common.AdminURL + '/DistOneAPi/SubmitPO', model, { headers: reqHeader });
  }

}
