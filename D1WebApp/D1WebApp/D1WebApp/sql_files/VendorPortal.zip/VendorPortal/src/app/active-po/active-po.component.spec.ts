import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActivePoComponent } from './active-po.component';

describe('ActivePoComponent', () => {
  let component: ActivePoComponent;
  let fixture: ComponentFixture<ActivePoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActivePoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivePoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
