import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { LoadingModule } from 'ngx-loading';
import {NgxPaginationModule} from 'ngx-pagination'; // <-- import the module
import { AngularDateTimePickerModule } from 'angular2-datetimepicker';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatSelectModule } from '@angular/material/select';
import { AuthGuard } from '../../auth/auth.guard';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RouterModule } from '@angular/router';
import { appRoutes } from './routes';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { FooterComponent } from './components/footer/footer.component';
import { ActiveRfqComponent } from './active-rfq/active-rfq.component';
import { ViewRfqComponent } from './view-rfq/view-rfq.component';
import { ViewPoComponent } from './view-po/view-po.component';
import { ActivePoComponent } from './active-po/active-po.component';
import { LoginService } from './services/login.service';
import { QuoteService } from './services/quote.service';
import { PoService } from './services/po.service';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { LoadingService } from './services/loading.service';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { LoadingBarHttpClientModule } from '@ngx-loading-bar/http-client';
import { ToastrModule } from 'ngx-toastr';
import { RecaptchaModule } from 'ng-recaptcha';
import { TrackingManageComponent } from './tracking-manage/tracking-manage.component';
import { ItemsComponent } from './items/items.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    SidebarComponent,
    NavbarComponent,
    FooterComponent,
    ActiveRfqComponent,
    ViewRfqComponent,
    ViewPoComponent,
    ActivePoComponent,
    TrackingManageComponent,
    ItemsComponent,
    
  ],
  imports: [
    BrowserModule,
    ToastrModule.forRoot(),
    RouterModule.forRoot(appRoutes),
    BrowserAnimationsModule,
    MatSelectModule,
    FormsModule,
    HttpClientModule,
    LoadingModule,
    MatCheckboxModule,
    NgxPaginationModule,
    LoadingBarHttpClientModule,
    RecaptchaModule.forRoot(),
    AngularDateTimePickerModule
  ],
  providers: [QuoteService, AuthGuard,PoService,LoginService, LoadingService, {provide: LocationStrategy, useClass: HashLocationStrategy}],
  bootstrap: [AppComponent]
})
export class AppModule { }
