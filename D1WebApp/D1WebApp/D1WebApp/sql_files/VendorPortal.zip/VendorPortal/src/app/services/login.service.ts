import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { Login } from '../models/login.model';
import { Common } from './common.model';

@Injectable()
export class LoginService {

  common: Common;
  constructor(private http: HttpClient) {
    this.common = new Common();
  }

  userLogin(userName, password) {    
    const body: Login = {
      UserName:userName,
      Password:password,
      UserID:this.common.UserID,
    }
    var reqHeader = new HttpHeaders({ 'Content-Type': 'application/json', 'No-Auth': 'True', 'Access-Control-Allow-Origin': '*' });
    return this.http.post(this.common.AdminURL + '/Account/VendorLogin', JSON.stringify(body), { headers: reqHeader });

    }

}
