import { Component, OnInit } from '@angular/core';

import { NgForm } from '@angular/forms';
import { LoginService } from '../services/login.service';
import { Router } from '@angular/router';


import { HttpErrorResponse } from '@angular/common/http';
import { LoadingService } from '../services/loading.service';
import {Md5} from 'ts-md5/dist/md5';
import { RecaptchaModule } from 'ng-recaptcha';
import { RecaptchaFormsModule } from 'ng-recaptcha/forms';

@Component({
  providers: [Md5,RecaptchaModule,RecaptchaFormsModule],
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {  
  UserType = "1";
  Errormsg:string='';
  isLoginError: boolean = false;
  captcha1:string=null;
  
  
  constructor(private loginService:LoginService,private _md5: Md5,private router: Router,private loadingService:LoadingService) { 
    
  }
  
  ngOnInit() {

  }
  resolved(captchaResponse: string) {
    this.captcha1=captchaResponse;
    if(this.captcha1!=null){
      this.isLoginError=false;
    }
}
  OnSubmit(form: NgForm) {
    // if(this.captcha1==null){
    //   this.Errormsg='Please Click on Captcha CheckBox';
    //   this.isLoginError=true;
      
    // }
    // else{
    this.loginService.userLogin(form.value.UserName,Md5.hashStr(form.value.Password)).subscribe((data: any) => {
      if (data == "Failed") {
        this.Errormsg='Invalid UserName Or Password';
        this.isLoginError = true;        
      }
      else{
        localStorage.setItem('vendor',data);
         this.router.navigate(['/dashboard']);
      }
    },
    (err: HttpErrorResponse) => {
      this.isLoginError = true;
    });
  // }
}
  sendMessage(message): void {
    this.loadingService.LoadingMessage(message);
  }
}
