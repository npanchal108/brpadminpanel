export class Login {
    UserName: string;
    Password: string;
    UserID:number;
}
