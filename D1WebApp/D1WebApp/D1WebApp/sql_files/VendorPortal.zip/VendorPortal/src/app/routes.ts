import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ActiveRfqComponent } from './active-rfq/active-rfq.component';
import { ViewRfqComponent } from './view-rfq/view-rfq.component';
import { ViewPoComponent } from './view-po/view-po.component';
import { ActivePoComponent } from './active-po/active-po.component';
import { AuthGuard } from '../../auth/auth.guard';
import { TrackingManageComponent } from './tracking-manage/tracking-manage.component';
import { ItemsComponent } from './items/items.component';


export const appRoutes: Routes = [
    {
        path: 'login', component: LoginComponent
    },
    {
        path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard]
    },
    {
        path: 'active-rfq', component: ActiveRfqComponent, canActivate: [AuthGuard]
    },
    {
        path: 'view-rfq/:quoteNo', component: ViewRfqComponent, canActivate: [AuthGuard]
    },
    {
        path: 'view-rfq/:quoteNo/:partNo', component: ViewRfqComponent, canActivate: [AuthGuard]
    },
    {
        path: 'active-po', component: ActivePoComponent, canActivate: [AuthGuard]
    },
    {
        path: 'view-po/:poNo', component: ViewPoComponent, canActivate: [AuthGuard]
    },
    {
        path: 'view-po/:poNo/:partNo', component: ViewPoComponent, canActivate: [AuthGuard]
    },
    {
        path: 'tracking/:poNo', component: TrackingManageComponent, canActivate: [AuthGuard]
    }, 
    {
        path: 'tracking/:poNo/:partNo', component: TrackingManageComponent, canActivate: [AuthGuard]
    }, 
    {
        path: 'items', component: ItemsComponent, canActivate: [AuthGuard]
    }, 
    {
        path: '', redirectTo: '/login', pathMatch: 'full'
    }
]