export class Common {
       UserID:number=parseInt("{{UserID}}");
       AdminURL: string = '{{AdminURL}}';
      //UserID:number=10172;
      //AdminURL: string = 'https://portal.distone.com/WebApi';
      //AdminURL: string ='http://localhost:38051';
}
