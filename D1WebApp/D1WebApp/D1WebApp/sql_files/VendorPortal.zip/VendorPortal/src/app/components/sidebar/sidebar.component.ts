import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

declare const $: any;
declare interface RouteInfo {
  path: string;
  title: string;
  icon: string;
  class: string;
}
export const ROUTES: RouteInfo[] = [
  { path: 'dashboard', title: 'Dashboard', icon: 'dashboard', class: '' },
  { path: 'active-rfq', title: 'Active RFQ', icon: 'receipt', class: '' },
  { path: 'active-po', title: 'Active PO', icon: 'receipt', class: '' },

  // { path: 'icons', title: 'Icons', icon: 'bubble_chart', class: '' },
  // { path: 'maps', title: 'Maps', icon: 'location_on', class: '' },
  // { path: 'notifications', title: 'Notifications', icon: 'notifications', class: '' },
  // { path: 'upgrade', title: 'Upgrade to PRO', icon: 'unarchive', class: 'active-pro' },
];


@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
  menuItems: any[];

  constructor(private router: Router) { }

  ngOnInit() {
    this.menuItems = ROUTES.filter(menuItem => menuItem);
    //$.getScript('../../assets/js/sidebar-moving-tab.js');
  }
  isMobileMenu() {
    if ($(window).width() > 991) {
      return false;
    }
    return true;
  };

  sidebarClose() {
    const body = document.getElementsByTagName('body')[0];
    body.classList.remove('nav-open');
    $('.navbar-toggle').removeClass('toggled');
  };

  MenuClick(path) {
    $(this).addClass('active');
    this.sidebarClose();
    this.router.navigate([path]);
  }
  Logout() {
    this.sidebarClose();
    localStorage.removeItem('AuthenticationToken');
    localStorage.removeItem('MemberReferenceNo');
    localStorage.removeItem('LoginUserID');
    this.router.navigate(['/login']);
  }

  GoToDashboard(){
    $('.nav li').removeClass('active');
    $('#liDashboard').addClass('active');
    this.sidebarClose();
    this.router.navigate(['/dashboard'])
  }

  GoToRFQ(){
    $('.nav li').removeClass('active');
    $('#liRFQ').addClass('active');
    this.sidebarClose();
    this.router.navigate(['/active-rfq'])
  }

  GoToPO(){
    $('.nav li').removeClass('active');
    $('#liPO').addClass('active');
    this.sidebarClose();
    this.router.navigate(['/active-po'])
    
  }

  GoToItems(){
    $('.nav li').removeClass('active');
    $('#liItems').addClass('active');
    this.sidebarClose();
    this.router.navigate(['/items'])
    
  }
  
}
