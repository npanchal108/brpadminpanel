import { Component, OnInit } from '@angular/core';
import { LoadingService } from '../services/loading.service';
import { PoService } from '../services/po.service';
import { THROW_IF_NOT_FOUND } from '../../../node_modules/@angular/core/src/di/injector';
import { NgForm } from '../../../node_modules/@angular/forms';

@Component({
  selector: 'app-items',
  templateUrl: './items.component.html',
  styleUrls: ['./items.component.css']
})
export class ItemsComponent implements OnInit {

  searchParam: any = [];
  page: number = 1;
  totalPage: number
  itemList: any;
  itemstoavails: string = '';
  warehouse: string = '';

  constructor(private poService: PoService, private loadingService: LoadingService) { }

  ngOnInit() {
    this.getItemListCount();
    this.getItemList(this.page);
  }

  getItemList(pageNo) {
    this.searchParam.Item = this.searchParam.Item == undefined ? '' : this.searchParam.Item;
    this.searchParam.VendorItem = this.searchParam.VendorItem == undefined ? '' : this.searchParam.VendorItem;
    this.searchParam.Warehouse = this.searchParam.Warehouse == undefined ? '' : this.searchParam.Warehouse;

    this.poService.getItemList(this.searchParam.Item, this.searchParam.VendorItem, this.searchParam.Warehouse, pageNo).subscribe((res: any) => {
debugger;
      var result = res;

      this.itemstoavails = '';
      this.warehouse = '';
      for (let rr of res) {
        this.itemstoavails = this.itemstoavails + rr.item_item + ',';
        this.warehouse = this.warehouse + rr.wa_item_warehouse + ',';
      }

      var getitem = {
        items: this.itemstoavails,
        warehouse: this.warehouse,
      }

      this.poService.getItemAvailibilty(getitem).subscribe((res1:any) => {
        var availdata = res1;
        for (var i = 0; i < result.length; i++) {
          for (var j = 0; j < availdata.length; j++) {
            if (result[i].item_item == availdata[j].item) {
                result[i].AvailQTY = availdata[j].available;
            }
          }
        }

        this.itemList = result;

        console.log("avail qty : ", this.itemList);

      });
      
    });
    return pageNo;
  }

  getItemListCount() {
    this.searchParam.Item = this.searchParam.Item == undefined ? '' : this.searchParam.Item;
    this.searchParam.VendorItem = this.searchParam.VendorItem == undefined ? '' : this.searchParam.VendorItem;
    this.searchParam.Warehouse = this.searchParam.Warehouse == undefined ? '' : this.searchParam.Warehouse;

    this.poService.getItemListCount(this.searchParam.Item, this.searchParam.VendorItem, this.searchParam.Warehouse).subscribe((res: any) => {
      console.log("count result : ", res);
      this.totalPage = (res == null ? 0 : res.length);
    });
  }

  search() {
    console.log("search page : ", this.page);
    this.getItemListCount();
    this.getItemList(this.page);
  }

  OnClear() {
    this.searchParam = []
      this.getItemList(this.page);
  }
}
