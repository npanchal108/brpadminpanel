import { Component, OnInit } from '@angular/core';
import { QuoteService } from '../services/quote.service';
import { ActivatedRoute, Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-tracking-manage',
  templateUrl: './tracking-manage.component.html',
  styleUrls: ['./tracking-manage.component.css']
})
export class TrackingManageComponent implements OnInit {

  poNo: string;
  partNo: string;
  vendor: string;
  trackingModel: any = {};
  isSuccess: boolean = false;

  constructor(private quoteService: QuoteService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    this.poNo = this.route.snapshot.paramMap.get('poNo');
    this.partNo = this.route.snapshot.paramMap.get('partNo');
    this.vendor = localStorage.getItem("vendor");
  }

  saveTracking() {
    console.log("model : ", this.trackingModel);
    this.trackingModel.Order = this.poNo;
    this.quoteService.insertTracking(this.trackingModel).subscribe((res: any) => {
      console.log("This is tracking result : ", res);

      if (res.created == 1) {
        this.isSuccess = true;
        this.trackingModel = {};
      }

    });
  }
  cancel() {
    debugger;
    console.log("part no : ",this.partNo);
    if (this.partNo == null || this.partNo == undefined)
      this.router.navigate(['/view-po', this.poNo]);
    else
      this.router.navigate(['/view-po', this.poNo, this.partNo]);
  }
}
